package lec;

public class CompanyEntity {
	
	private String com;  //ȸ���
	private String location;   //ȸ��_������
	private String person;  //��ǥ��
	private String category;   //����о�
	private int money;   //�����
	private int employee; //������
	private int scale;   //ä��Ը�
	
	
	
	
	public String getCom() {
		return com;
	}
	public void setCom(String com) {
		this.com = com;
	}
	
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
	public int getEmployee() {
		return employee;
	}
	public void setEmployee(int employee) {
		this.employee = employee;
	}
	
	
	public int getScale() {
		return scale;
	}
	public void setScale(int scale) {
		this.scale = scale;
	}
	
	
	
	
	
}
